-- Add down migration script here
DROP INDEX ix_messagedestination_per_msg_no_status;
