ALTER TABLE message DROP COLUMN updated_at;
ALTER TABLE messageattempt DROP COLUMN updated_at;
