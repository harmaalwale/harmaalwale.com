ALTER TABLE endpoint DROP COLUMN headers;
