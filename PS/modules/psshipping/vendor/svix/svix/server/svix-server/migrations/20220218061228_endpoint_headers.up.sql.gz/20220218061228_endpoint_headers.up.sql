ALTER TABLE endpoint ADD COLUMN headers jsonb;
