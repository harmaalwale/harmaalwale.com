-- Add down migration script here
DROP TABLE IF EXISTS endpointmetadata;