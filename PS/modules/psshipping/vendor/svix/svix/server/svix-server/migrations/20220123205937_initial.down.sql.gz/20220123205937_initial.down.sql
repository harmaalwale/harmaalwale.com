DROP TABLE application;


DROP TABLE endpoint;


DROP TABLE eventtype;


DROP TABLE message;


DROP TABLE messageattempt;


DROP TABLE messagedestination;
